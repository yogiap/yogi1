<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Home | Web Framework'
        ];

        return view('pages/home', $data);
    }
    public function about()
    {
        $data = [
            'title' => 'About | Web Framework'
        ];

        return view('pages/about', $data);
    }
    public function contact()
    {
        $data = [

            'title' => 'Contact Us',
            'alamat' => [
                [
                    'tipe' => 'Perguruan Tinggi',
                    'alamat' => 'Jln. Pelor Mas III Kampus Universitas Teknologi Mataram',
                    'kota' => 'Mataram'
                ],
                [
                    'tipe' => 'Rumah',
                    'alamat' => 'Jln. Macan Coklat',
                    'kota' => 'Lombok Utara'
                ],
                [
                    'tipe' => 'Kantor',
                    'alamat' => 'Jln. Prawira Tanjung',
                    'kota' => 'Lombok Utara'
                ]
            ]
        ];
        return view('pages/contact', $data);
    }
}

<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>DAFTAR KOMIK</h1>
            <table class="table">
  <thead>
    <tr>
      <th scope="col">no</th>
      <th scope="col">Sampul</th>
      <th scope="col">Group</th>
      <th scope="col">Prodi</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td><img src="/CI4/public/img/Onepice.jpg" alt="" class="sampul"></td>
      <td>Group tiktok</td>
      <td>
        <a href="" class="btn btn-success">Teknik informatika>

        </td>
    </tr>
    
  </tbody>
</table>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>
<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h3>Welcome to cari jodoh</h3>
            <h4>About Us</h4>
            <p>selamat datang di group pencari jodoh</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>
<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h3>Framework CI4</h3>
            <p>Belajar Framework Ci 4</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>